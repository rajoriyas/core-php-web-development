<?php

class  N2SSSlidePlacementDefault extends N2SSSlidePlacement {

    public function attributes(&$attributes) {

        $attributes['data-pm'] = 'default';
    }
}