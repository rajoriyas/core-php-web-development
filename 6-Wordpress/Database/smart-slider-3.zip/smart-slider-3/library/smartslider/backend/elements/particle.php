<?php
N2Localization::addJS(array(
    'You can generate at %s Then <i>Download current config (json)</i> and paste content into the field.',
));