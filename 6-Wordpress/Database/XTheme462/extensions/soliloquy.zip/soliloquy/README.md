Soliloquy
==============

Soliloquy is the best responsive WordPress slider plugin. Period.

**Copyright &copy; 2014 Griffin Media, LLC. All rights reserved.**