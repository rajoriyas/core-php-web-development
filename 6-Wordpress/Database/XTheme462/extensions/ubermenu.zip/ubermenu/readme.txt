

////////////////////////
//
// Welcome to UberMenu!
//
////////////////////////


http://wpmegamenu.com


All UberMenu Documentation can be found online at http://sevenspark.com/docs/ubermenu-3/

The resources are linked from within the plugin interface


===========================
QUICK START GUIDE
===========================

http://sevenspark.com/docs/ubermenu-3/quick-start



===========================
INSTALLATION INSTRUCTIONS
===========================

http://sevenspark.com/docs/ubermenu-3/install



===========================
DOCUMENTATION / SUPPORT RESOURCES
===========================

Knowledgebase		http://sevenspark.com/docs/ubermenu-3/
Video Tutorials 	http://sevenspark.com/docs/ubermenu-3/video-tutorials
Troubleshooter		http://sevenspark.com/symptom/ubermenu-symptoms
Support Center		http://sevenspark.com/help

